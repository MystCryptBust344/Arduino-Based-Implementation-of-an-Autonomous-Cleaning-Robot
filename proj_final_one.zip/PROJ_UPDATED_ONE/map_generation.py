import numpy as np

def update_global_map(global_map, local_map, position):
    gx, gy = position
    if gx + local_map.shape[0] > global_map.shape[0] or gy + local_map.shape[1] > global_map.shape[1]:
        print("Error: Local map exceeds global map bounds.")
        return global_map

    global_map[gx:gx+local_map.shape[0], gy:gy+local_map.shape[1]] = local_map
    return global_map

if __name__ == "__main__":
    global_map = np.zeros((200, 200), dtype=np.uint8)
    local_map = np.ones((50, 50), dtype=np.uint8) * 255
    updated_map = update_global_map(global_map, local_map, (75, 75))
    print("Updated Global Map:")
    print(updated_map)
