import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-entity', 'robot', '-file', '/path/to/your_robot.urdf'],
            output='screen'
        ),
        Node(
            package='your_robot_package',
            executable='robot_control_node',
            name='robot_control',
            output='screen'
        )
    ])
