import cv2
import numpy as np

def estimate_position(edges):
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    positions = [cv2.boundingRect(cnt) for cnt in contours]
    return positions

if __name__ == "__main__":
    frame = cv2.imread("sample.jpg", cv2.IMREAD_GRAYSCALE)
    edges = cv2.Canny(frame, 50, 150)
    positions = estimate_position(edges)
    print("Detected Positions:", positions)
