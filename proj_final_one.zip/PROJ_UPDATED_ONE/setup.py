from setuptools import setup

package_name = 'my_robot_package'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='you@example.com',
    description='ROS 2 package for vacuum robot simulation',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'camera_capture = my_robot_package.camera_capture:main',
            'image_processing = my_robot_package.image_processing:main',
            'obstacle_detection = my_robot_package.obstacle_detection:main',
            'path_planning = my_robot_package.path_planning:main',
            'map_generation = my_robot_package.map_generation:main',
            'self_localization = my_robot_package.self_localization:main',
        ],
    },
)
