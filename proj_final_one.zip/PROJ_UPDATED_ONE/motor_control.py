import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial
import time

# Serial communication with Arduino
SERIAL_PORT = '/dev/ttyUSB0'  # Change based on your setup
BAUD_RATE = 9600

class MotorControl(Node):
    def __init__(self):
        super().__init__('motor_control')
        self.subscription = self.create_subscription(
            Twist,
            'cmd_vel',
            self.command_callback,
            10
        )
        self.serial_conn = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
        time.sleep(2)  # Allow serial connection to establish

    def command_callback(self, msg):
        linear_speed = int(msg.linear.x * 255)  # Convert to PWM range
        angular_speed = int(msg.angular.z * 255)
        command = f'{linear_speed},{angular_speed}\n'
        self.serial_conn.write(command.encode())
        self.get_logger().info(f'Sent command: {command}')

    def stop_robot(self):
        self.serial_conn.write(b'0,0\n')
        self.get_logger().info('Robot stopped')
        self.serial_conn.close()

def main(args=None):
    rclpy.init(args=args)
    motor_control = MotorControl()
    try:
        rclpy.spin(motor_control)
    except KeyboardInterrupt:
        motor_control.stop_robot()
        motor_control.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
