import cv2
import numpy as np

def match_angles(edges):
    angles = []  # Initialize angles list
    if edges is None:
        print("Error: Edges input is None.")
        return angles  # Return empty list to prevent further errors

    lines = cv2.HoughLinesP(edges, 1, np.pi/180, 50, minLineLength=50, maxLineGap=10)
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
            angles.append(angle)
    return angles

if __name__ == "__main__":
    frame = cv2.imread("sample.jpg", cv2.IMREAD_GRAYSCALE)

    if frame is None:
        print("Error: Could not read 'sample.jpg'. Check the file path!")
    else:
        edges = cv2.Canny(frame, 50, 150)
        angles = match_angles(edges)
        print("Detected Angles:", angles)
