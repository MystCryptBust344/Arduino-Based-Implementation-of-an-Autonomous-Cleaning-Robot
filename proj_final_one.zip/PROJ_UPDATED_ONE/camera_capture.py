import cv2

def capture_frame():
    cap = cv2.VideoCapture(0)  # Open the camera
    if not cap.isOpened():
        print("Error: Could not open camera.")
        return None
    
    ret, frame = cap.read()
    cap.release()
    if not ret:
        print("Error: Could not read frame.")
        return None
    
    return frame

if __name__ == "__main__":
    frame = capture_frame()
    if frame is not None:
        cv2.imshow("Captured Frame", frame)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
