import numpy as np
import heapq

def dijkstra(grid_map, start, end):
    rows, cols = grid_map.shape
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    pq = [(0, start)]
    distances = {start: 0}
    paths = {start: None}
    
    while pq:
        cost, current = heapq.heappop(pq)
        if current == end:
            break
        for dx, dy in directions:
            neighbor = (current[0] + dx, current[1] + dy)
            if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols and grid_map[neighbor] == 0:
                new_cost = cost + 1
                if neighbor not in distances or new_cost < distances[neighbor]:
                    distances[neighbor] = new_cost
                    heapq.heappush(pq, (new_cost, neighbor))
                    paths[neighbor] = current
    
    path = []
    while end in paths:
        path.append(end)
        end = paths[end]
    return path[::-1]

if __name__ == "__main__":
    grid_map = np.zeros((10, 10), dtype=np.uint8)
    start, end = (0, 0), (9, 9)
    path = dijkstra(grid_map, start, end)
    print("Computed Path:", path)
