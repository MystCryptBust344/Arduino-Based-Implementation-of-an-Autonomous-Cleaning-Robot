import cv2
import numpy as np

def calibrate_camera():
    obj_points = []  # 3D points in real world
    img_points = []  # 2D points in image plane
    
    objp = np.zeros((6 * 7, 3), np.float32)
    objp[:, :2] = np.mgrid[0:7, 0:6].T.reshape(-1, 2)
    
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open camera.")
        return
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        ret, corners = cv2.findChessboardCorners(gray, (7, 6), None)
        if ret:
            img_points.append(corners)
            obj_points.append(objp)
            cv2.drawChessboardCorners(frame, (7, 6), corners, ret)
        
        cv2.imshow("Calibration", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    return obj_points, img_points

if __name__ == "__main__":
    calibrate_camera()
