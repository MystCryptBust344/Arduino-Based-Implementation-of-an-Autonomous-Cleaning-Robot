import cv2
import numpy as np

def analyze_image(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_floor = np.array([0, 0, 100])
    upper_floor = np.array([255, 50, 255])
    mask = cv2.inRange(hsv, lower_floor, upper_floor)
    return mask

if __name__ == "__main__":
    frame = cv2.imread("sample.jpg")
    mask = analyze_image(frame)
    cv2.imshow("Floor Mask", mask)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
