import cv2
import numpy as np

def edge_detection(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    return edges

if __name__ == "__main__":
    frame = cv2.imread("sample.jpg")
    edges = edge_detection(frame)
    cv2.imshow("Edge Detection", edges)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
