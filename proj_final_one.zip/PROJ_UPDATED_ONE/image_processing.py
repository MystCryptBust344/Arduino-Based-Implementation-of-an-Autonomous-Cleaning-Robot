import cv2
import numpy as np

def preprocess_image(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)  # Apply Gaussian blur
    thresh = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY)[1]  # Thresholding
    return thresh

if __name__ == "__main__":
    frame = cv2.imread("sample.jpg")  # Load a sample image
    processed_frame = preprocess_image(frame)
    cv2.imshow("Processed Image", processed_frame)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
