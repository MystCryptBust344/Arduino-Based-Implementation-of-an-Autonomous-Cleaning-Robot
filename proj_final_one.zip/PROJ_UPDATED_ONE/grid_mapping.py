import numpy as np

def generate_grid_map(frame_size, positions):
    grid_map = np.zeros(frame_size, dtype=np.uint8)
    for x, y, w, h in positions:
        grid_map[y:y+h, x:x+w] = 255  # Mark obstacles

    return grid_map

if __name__ == "__main__":
    positions = [(10, 10, 30, 30), (50, 50, 20, 20)]
    grid_map = generate_grid_map((100, 100), positions)
    print("Generated Grid Map:")
    print(grid_map)
