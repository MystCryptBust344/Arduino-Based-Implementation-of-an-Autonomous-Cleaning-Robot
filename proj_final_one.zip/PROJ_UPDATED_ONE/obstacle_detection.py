import cv2
import numpy as np

def detect_obstacles(frame):
    if frame is None:
        print("Error: Frame is None.")
        return None

    blurred = cv2.GaussianBlur(frame, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)

    return edges

if __name__ == "__main__":
    frame = cv2.imread("sample.jpg", cv2.IMREAD_GRAYSCALE)
    if frame is None:
        print("Error: Could not load image.")
    else:
        edges = detect_obstacles(frame)
        cv2.imshow("Obstacle Detection", edges)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
